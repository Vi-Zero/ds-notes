% Experiment 6: Transient heating of a steel ball (lumped system)
% rho*V*Cp*dT/dt = h*A*(Ta - T),  analytical solution T = Ta - (Ta - T0)*exp(-K*t)

Cp = 400;
Ta = 400;
h = 3000;
rho = 8000;
d = 0.1;

r = d/2;
A = 4*pi*r^2;
V = (4/3)*pi*r^3;

K = h*A/(rho*V*Cp);

t = 0:0.25:5;

T = Ta - (Ta-300)*exp(-K*t);

disp([t' T'])
plot(t,T)
xlabel('Time (s)')
ylabel('Temperature (K)')
title('Temperature of Steel Ball vs Time')
grid on
