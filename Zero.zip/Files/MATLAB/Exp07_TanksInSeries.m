% Experiment 7: ODE series model (first-order reaction A -> B in three CSTRs in series)

k = 0.5;
tau = 2;
CA0 = 1.8;
y0 = [0.4; 0.2; 0.1];

% dCA/dt for each tank
f = @(t,C) [(CA0 - C(1))/tau - k*C(1);
            (C(1) - C(2))/tau - k*C(2);
            (C(2) - C(3))/tau - k*C(3)];

%time points: 0, 0.5,...10
tspan = 0:0.5:10;

%solve ODE
[t, C] = ode45(f, tspan, y0);

%Create matrix_type
S = [t C];
disp(S)

%plot
plot(t, C, 'LineWidth', 1.5);
xlabel('time'); ylabel('C_A (kmol/m^3)');
legend('C_{A1}', 'C_{A2}', 'C_{A3}'); grid on;

% Steady state (algebraic): set dC/dt = 0
A = [1/tau + k, 0,         0;
     -1/tau,    1/tau + k, 0;
     0,         -1/tau,    1/tau + k];
b = [CA0/tau; 0; 0];
Css = A\b
