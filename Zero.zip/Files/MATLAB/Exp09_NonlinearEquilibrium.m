% Experiment 9: System of non-linear algebraic equations (gas-phase equilibrium)
% Newton's method with a numerical Jacobian and step-halving damping

clc; clear;

Kc1 = 1.063; Kc2 = 2.63; Kc3 = 5;
Ca0 = 1.5;
Cb0 = 1.5;

% x = [Ca Cb Cc Cd Cx Cy Cz]
f = @(x) [ ...
    Kc1*x(1)*x(2) - x(3)*x(4);         % Kc1*Ca*Cb = Cc*Cd
    Kc2*x(2)*x(3) - x(5)*x(6);         % Kc2*Cb*Cc = Cx*Cy
    Kc3*x(1)*x(5) - x(7);              % Kc3*Ca*Cx = Cz
    x(1) - (Ca0 - x(4) - x(7));        % Ca = Ca0 - Cd - Cz
    x(2) - (Cb0 - x(4) - x(6));        % Cb = Cb0 - Cd - Cy
    x(3) - (x(4) - x(6));              % Cc = Cd - Cy
    x(6) - (x(5) + x(7)) ];            % Cy = Cx + Cz

x = zeros(7,1);     % initial guess (also try ones(7,1), 10*ones(7,1))
h = 1e-7;

for k = 1:100
    F = f(x);
    J = zeros(7,7);     % numerical Jacobian
    for j = 1:7
        e = zeros(7,1); e(j) = h;
        J(:,j) = (f(x+e) - F)/h;
    end

    dx = -pinv(J)*F;    % Newton step
    t = 1;              % damping if step makes things worse

    while norm(f(x+t*dx)) > norm(F) && t > 1e-4
        t = t/2;
    end
    x = x + t*dx;
    if norm(dx) < 1e-10, break; end
end

names = {'Ca','Cb','Cc','Cd','Cx','Cy','Cz'};
for i = 1:7
    fprintf('%s = %.3f\n', names{i}, x(i));
end
fprintf('Iterations: %d\n', k);
