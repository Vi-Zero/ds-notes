% Experiment 8: ODE of bioreactor (chemostat)

% Parameters
muM = 0.53;     % max specific growth rate (1/h)
K   = 0.12;     % saturation constant (g/L)
D   = 0.3;      % dilution rate F/V (1/h)
Y   = 0.4;      % yield factor
Sf  = 4;        % feed substrate conc. (g/L)

% ODEs: y(1) = biomass x, y(2) = substrate S
mu = @(S) muM*S./(K+S);
f  = @(t,y) [ mu(y(2))*y(1) - D*y(1);
              D*(Sf - y(2)) - mu(y(2))*y(1)/Y ];

% Solve (same initial values as your sheet: x0 = 4, S0 = 0)
tspan = linspace(0, 50, 21);    % 20 intervals like RKadapt
[t, y] = ode45(f, tspan, [4; 0]);

% Results table
fprintf('\n%-10s %-15s %-15s\n', 'Time(h)', 'Biomass(g/L)', 'Substrate(g/L)');
fprintf('------------------------------------------------\n');

for i = 1:length(t)
    fprintf('%-10.2f %-15.4f %-15.4f\n', t(i), y(i,1), y(i,2));
end

fprintf('Biomass   = %.3f g/L\n', y(end,1));
fprintf('Substrate = %.3f g/L\n', y(end,2));
fprintf('mu = %.3f\n', mu(y(end,2)));     % should equal D = 0.3

% Plot
plot(t, y(:,1), 'b-o', t, y(:,2), 'r-s', 'LineWidth', 1.5)
xlabel('Time (h)'); ylabel('Concentration (g/L)')
legend('Biomass', 'Substrate'); grid on
title('Chemostat bioreactor')
